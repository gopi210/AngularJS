This is meant to be a gentle introduction to combining AngularJS and Elasticsearch through a simple example

**Behold the "Hello World" of AngularJS / Elasticsearch**
