searchApp.controller('Stackoverflow', function($scope, ejsResource){
});