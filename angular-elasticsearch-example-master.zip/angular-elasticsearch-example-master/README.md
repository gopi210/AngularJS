angular-elasticsearch-example
=============================

A small application to get started with Angular and elasticsearch, for more information check out this blog post: http://blog.comperiosearch.com/blog/2013/10/24/instant-search-with-angularjs-and-elasticsearch/
